/* eslint-disable no-unused-vars */

import React from 'react'

function Statistics() {
  return (
    <div className='text-center fw-bold'>Statistics</div>
  )
}

export default Statistics