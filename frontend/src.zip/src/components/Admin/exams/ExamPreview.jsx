import React from 'react'

function ExamPreview() {
  return (
    <div>ExamPreview</div>
  )
}

export default ExamPreview