
/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import Service from '../../../service/Service';
import { Dialog, DialogTitle, DialogContent, Button, Typography, Radio, RadioGroup, FormControlLabel, Stack, IconButton, Divider } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';


const QuestionPreview = ({ ID, onClose }) => {
    const [question, setQuestion] = useState(null);

    useEffect(() => {
        if (ID) {
            Service.get(`/api/question/${ID}`).then((response) => {
                console.log("Question", response.data);
                setQuestion(response.data);
            });
        }
    }, [ID]);

    if (!question) return null;
    console.log("Question Options:", question.options, typeof question.options);
    console.log("Question correct answer:", question.correctAnswer, typeof question.correctAnswer);

    return (
        <Dialog
            open
            onClose={onClose}
            
            sx={{
                '& .MuiDialog-paper': {
                    width:"1000px",
                    borderRadius: '12px',
                },
            }}
        >
            <DialogTitle>
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <Typography style={{fontSize:"17px", fontWeight:"bold"}}>Question Id: {question.QID}</Typography>
                    <IconButton onClick={onClose}>
                        <CloseIcon />
                    </IconButton>
                </Stack>
            </DialogTitle>

            <DialogContent>
                <Stack spacing={2}>
                    <Stack direction="row" justifyContent="space-between" divider={<Divider orientation="vertical" flexItem />}>
                        <Typography variant="body2">
                            <strong>Section:</strong> {question.section || 'N/A'}
                        </Typography>
                        <Typography variant="body2">
                            <strong>Type:</strong> {question.questionType || 'N/A'}
                        </Typography>
                        <Typography variant="body2">
                            <strong>Positive Marks:</strong> {question.score}
                        </Typography>
                        <Typography variant="body2">
                            <strong>Negative Marks:</strong> {question.negativeMarks}
                        </Typography>
                    </Stack>

                    <Divider />

                    <Typography variant="body">
                        Question: {question.questionName}
                    </Typography>


                    <RadioGroup>
                    Options :
                        {(Array.isArray(JSON.parse(question.options)) ? JSON.parse(question.options) : []).map((option, index) => (
                            <FormControlLabel
                                key={index}
                                style={{marginLeft:"10px"}}
                                value={option}
                                control={
                                    <Radio
                                        disabled
                                        checked={JSON.parse(question.correctAnswer || "[]").includes(option)} // Check if the option is a correct answer
                                    />
                                }
                                label={
                                    JSON.parse(question.correctAnswer || "[]").includes(option) ? (
                                        <span style={{ color: "green", fontWeight: "bold" }}>{option} (Correct Answer)</span>
                                    ) : (
                                        option
                                    )
                                }
                            />
                        ))}
                    </RadioGroup>

                    <Stack direction="row" justifyContent="space-between">
                        <Typography variant="body" >
                            <strong>Explaination: </strong>{question.description || 'No description available.'}
                        </Typography>
                    </Stack>

                    <Divider />
                    <Typography variant="caption" color="text.secondary">
                        Created on {new Date(question.createdOn).toLocaleString() || 'N/A'}
                    </Typography>
                </Stack>
            </DialogContent>
{/* 
            <Button
                variant="contained"
                color="primary"
                onClick={onClose}
                sx={{ margin: '16px auto', display: 'block', textTransform: 'none' }}
            >
                Close
            </Button> */}
        </Dialog>
    );
};

export default QuestionPreview;
