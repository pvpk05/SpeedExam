/* eslint-disable no-unused-vars*/
/* eslint-disable react/prop-types */

import React, { useEffect, useState, useRef } from 'react'
import Typography from '@mui/material/Typography';
import {
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    Radio,
    RadioGroup,
    FormControlLabel,
    TextField,
    Checkbox,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import ReactQuill from 'react-quill';
import Service from '../../../service/Service';
import { Link } from 'react-router-dom';
import { computeSlots } from '@mui/x-data-grid/internals';
import * as XLSX from 'xlsx';


function QuestionImport({ onBulkUpload }) {
    const fileInputRef = useRef(null);

    const handleButtonClick = () =>
        fileInputRef.current.click();

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = (event) => {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                const formattedData = formatData(json);
                onBulkUpload(formattedData);
            } catch (error) {
                console.error('Error parsing file:', error);
            }
        };

        reader.onerror = (error) => {
            console.error('Error reading file:', error);
        };

        reader.readAsArrayBuffer(file);
    };

    const formatData = (json) => {
        const headers = json[0];
        const data = json.slice(1);

        const pages_data = [];

        data.forEach((row) => {
            const question = {
                QID: row[headers.indexOf('S No.')],
                section: row[headers.indexOf('SUBJECT')],
                questionName: row[headers.indexOf('QUESTION TEXT')],
                options: [
                    row[headers.indexOf('OPTION1')],
                    row[headers.indexOf('OPTION2')],
                    row[headers.indexOf('OPTION3')],
                    row[headers.indexOf('OPTION4')],
                    row[headers.indexOf('OPTION5')],
                    row[headers.indexOf('OPTION6')],
                    row[headers.indexOf('OPTION7')],
                    row[headers.indexOf('OPTION8')],
                    row[headers.indexOf('OPTION9')],
                    row[headers.indexOf('OPTION10')]
                ].filter(option => option !== null && option !== undefined && (typeof option === 'string' ? option.trim() !== '' : true)),
                description: row[headers.indexOf('EXPLANATION')],
                questionType: row[headers.indexOf('QUESTION TYPE')],
                correctAnswer: [row[headers.indexOf('RIGHT ANSWER')]],
                score: row[headers.indexOf('CORRECT MARKS')],
                negativeMarks: row[headers.indexOf('NEGATIVE MARKS')],
            };
            console.log(question);
            pages_data.push(question);
        });
        console.log(pages_data);
        return {
            pages_data
        };
    };




    return (
        <div>
            <Button variant="contained" color="success" onClick={handleButtonClick} >
                Import
            </Button>
            <input
                type="file"
                accept=".xlsx"
                onChange={handleFileUpload}
                ref={fileInputRef}
                style={{ display: 'none' }}
            />
        </div>
    )
}

function QuestionBulkUpload() {
    const [bulkData, setBulkData] = useState([]); // Initialize with your data
    const [loading, setLoading] = useState(false);

    const handleInputChange = (field, value, index) => {
        const updatedBulkData = [...bulkData];


        // Check if the value being updated is an array
        if (Array.isArray(updatedBulkData[index][field]) && Array.isArray(value)) {
            // Merge or replace the array based on requirements (replace here for simplicity)
            updatedBulkData[index][field] = [...value];
        } else {
            // Handle non-array fields
            updatedBulkData[index][field] = value;
        }

        setBulkData(updatedBulkData); // Update the state
    };



    // const handleInputChange = (name, value, index) => {
    //     setFormState({ ...formState, [name]: value });
    //     setErr({ ...err, [name]: '' });
    //     setBulkData((prevData) =>
    //       prevData.map((item, idx) =>
    //         idx === index ? { ...item, [name]: value } : item
    //       )
    //     );
    //   }

    // const [bulkData, setBulkData] = useState([]);
    // const [loading, setLoading] = useState(false);

    // const handleInputChange = (name, value, index) => {
    //     setFormState({ ...formState, [name]: value });
    //     setErr({ ...err, [name]: '' });
    //     setBulkData((prevData) =>
    //         prevData.map((item, idx) =>
    //             idx === index ? { ...item, [name]: value } : item
    //         )
    //     );
    // }


    const stripHTML = (html) => {
        const doc = new DOMParser().parseFromString(html, "text/html");
        return doc.body.textContent || "";
    };
    const [err, setErr] = useState({});


    const handleBulkUpload = (data) => {
        setBulkData(data.pages_data);
        // toast.success('Data imported successfully!'); // Show success toast
    };

    const handleRemove = (index) => {
        const data = bulkData.filter((item, i) => i != index);
        setBulkData(data);

    }

    const [sectionsList, setSectionList] = useState([]);
    const sectionList = () => {
        Service.get('/getAllSections').then((res) => {
            console.log(res.data);
            setSectionList(res.data.result);
        })
            .catch((err) => {
                console.log(err);
            })
    }
    useEffect(() => {
        sectionList();
    }, [])

    const handleSelectionChange = (index, optionIndex) => {
        const updatedBulkData = [...bulkData];
        // Update only the correct answer array or the selected option's index
        updatedBulkData[index].correctAnswer = [optionIndex]; // or whatever logic you use for the selected index
        setBulkData(updatedBulkData);
    };



    const deleteOption = (questionIndex, optionIndex) => {
        setBulkData((prev) =>
            prev.map((item, idx) =>
                idx === questionIndex
                    ? {
                        ...item,
                        options: item.options.filter((_, optIdx) => optIdx !== optionIndex),
                    }
                    : item
            )
        );
    };


    const handleOptionChange = (index, optionIndex, value) => {
        const updatedBulkData = [...bulkData];
        updatedBulkData[index].options[optionIndex] = value; // Update the label of the specific option
        setBulkData(updatedBulkData);
    };



    const processBulkData = (bulkData) => {
        return bulkData.map((item) => {
            const sanitizedQuestionName = stripHTML(item.questionName);
            let correctAnswers = [];
            const { questionType, options, correctAnswer } = item;

            let updatedOptions = [...options];

            if (questionType === "yesno") {
                updatedOptions = [
                    { label: "Yes", isSelected: correctAnswer[0] === 0 },
                    { label: "No", isSelected: correctAnswer[0] === 1 },
                ];
                correctAnswers = [updatedOptions[correctAnswer[0]].label];
            } else if (questionType === "singleCorrect") {
                correctAnswers =
                    correctAnswer.length > 0 ? [options[correctAnswer[0]]] : [];
            } else if (questionType === "multipleCorrect") {
                correctAnswers = options
                    .filter((option) => option.isSelected)
                    .map((option) => option.label);
            }

            return {
                ...item,
                questionName: sanitizedQuestionName,
                options: updatedOptions,
                correctAnswers,
            };
        });
    };



    const handleSaveBulk = () => {

        const payloads = processBulkData(bulkData); // Process all bulk data dynamically
        setLoading(true);

        console.log(payloads)
        Service.post("/createQuestion", payloads)
            .then((res) => {
                alert("Questions successfully added!");
                setLoading(false);
                setBulkData([]); // Clear bulk data after successful save
            })
            .catch((err) => {
                console.error(err);
                setLoading(false);
                alert("Failed to add questions.");
            });
    };


    const handleAddOption = (index) => {
        const updatedBulkData = [...bulkData];

        // Find the question you're adding an option to
        const item = updatedBulkData[index];

        // Create the new option as a simple string (e.g., 'Option 5', 'Option 6', etc.)
        const newOption = `Option ${item.options.length + 1}`;

        // Add the new option to the options array
        item.options.push(newOption);
        console.log("New Option:", newOption);

        // Update the bulkData state
        setBulkData(updatedBulkData);
    };



    // const deleteOption = (index) =>
    //     setBulkData((prev) => ({
    //         ...prev,
    //         options: prev.options.filter((_, i) => i !== index),
    //     }));

    return (
        <div className="Create_container">
            <Typography variant="h4" component="h2" gutterBottom>
                Question Bulk Import
            </Typography>

            <QuestionImport onBulkUpload={handleBulkUpload} />

            <div >
                {bulkData.length > 0 ?
                    <div>
                        {bulkData.map((item, index) => (
                            <div className="bg-light rounded my-4 p-3" key={index}>
                                <form className="my-5">
                                    <div className="d-flex justify-content-between">
                                        <FormControl sx={{ m: 1, minWidth: 250 }} size="small">
                                            <InputLabel>Question Type</InputLabel>
                                            <Select
                                                label="Question Type"
                                                value={item.questionType}
                                                name="questionType"
                                                onChange={(e) =>
                                                    handleInputChange("questionType", e.target.value, index)
                                                }
                                            >
                                                <MenuItem value="singleCorrect">Single Correct</MenuItem>
                                                <MenuItem value="multipleCorrect">Multiple Correct</MenuItem>
                                                <MenuItem value="yesno">Yes / No</MenuItem>
                                            </Select>
                                            {/* {err.questionType && <span className="text-danger">{err.questionType}</span>} */}
                                        </FormControl>

                                        <FormControl sx={{ m: 1, minWidth: 250 }} size="small">
                                            <InputLabel>Section</InputLabel>
                                            <Select
                                                label="Section"
                                                value={item.section}
                                                name="section"
                                                onChange={(e) => handleInputChange("section", e.target.value, index)}
                                            >
                                                {sectionsList.map((section, index) => (
                                                    <MenuItem key={index} value={section.Section}>
                                                        {section.Section}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                            {/* {err.section && <span className="text-danger">{err.section}</span>} */}
                                        </FormControl>
                                    </div>

                                    <div className="mb-3">
                                        <ReactQuill
                                            theme="snow"
                                            name="questionName"
                                            value={item.questionName}
                                            onChange={(content) => handleInputChange("questionName", content, index)}
                                            placeholder="Write your question here..."
                                        />
                                        {/* {err.questionName && <span className="text-danger">{err.questionName}</span>} */}
                                    </div>

                                    {item.questionType && (
                                        <div className="p-3">
                                            <Button
                                                variant="contained"
                                                onClick={() => handleAddOption(index)}
                                                className="mb-3"
                                            >
                                                Add Option
                                            </Button>

                                            <div className="mt-3">
                                                {item.questionType === "yesno" ? (
                                                    <RadioGroup
                                                        value={item.correctAnswer[0]}
                                                        onChange={(e) =>
                                                            handleInputChange("correctAnswer", [parseInt(e.target.value, 10)], index)
                                                        }
                                                    >
                                                        <FormControlLabel value={0} control={<Radio />} label="Yes" />
                                                        <FormControlLabel value={1} control={<Radio />} label="No" />
                                                    </RadioGroup>
                                                ) : (
                                                    <div className="row">
                                                        {item.options.map((option, optionIndex) => (
                                                            <div
                                                                key={optionIndex}
                                                                className="col-md-6 d-flex align-items-center mb-2"
                                                            >
                                                                {item.questionType === "multipleCorrect" ? (
                                                                    <Checkbox
                                                                        // checked={option.isSelected}
                                                                        checked={item.correctAnswer.some(element => element.includes(optionIndex + 1))}
                                                                        onChange={() => handleSelectionChange(index, optionIndex + 1)}
                                                                    />
                                                                ) : (
                                                                    <Radio
                                                                        checked={item.correctAnswer.includes(optionIndex + 1)} // Assuming correctAnswer holds the index
                                                                        onChange={() => handleSelectionChange(index, optionIndex + 1)}
                                                                    />
                                                                )}
                                                                <TextField
                                                                    value={option ? option : " "} // Ensure label is being accessed
                                                                    onChange={(e) =>
                                                                        handleOptionChange(index, optionIndex, e.target.value)
                                                                    }
                                                                    placeholder={`Option ${optionIndex + 1}`}
                                                                    variant="outlined"
                                                                    size="small"
                                                                    className="me-2"
                                                                />
                                                                <Button
                                                                    onClick={() => deleteOption(index, optionIndex)}
                                                                    variant="contained"
                                                                    color="error"
                                                                    size="small"
                                                                >
                                                                    <DeleteIcon />
                                                                </Button>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    <TextField
                                        label="Description"
                                        multiline
                                        rows={3}
                                        variant="outlined"
                                        fullWidth
                                        value={item.description}
                                        onChange={(e) => handleInputChange("description", e.target.value, index)}
                                        className="mt-3"
                                    />
                                    {/* {err.description && <span className="text-danger">{err.description}</span>} */}

                                    <div className="d-flex justify-content-between align-items-center mt-4">
                                        <div>
                                            <TextField
                                                label="Score"
                                                type="number"
                                                size="small"
                                                value={item.score}
                                                onChange={(e) => handleInputChange("score", e.target.value, index)}
                                            />
                                            {/* {err.score && <span className="text-danger">{err.score}</span>} */}
                                        </div>

                                        <div>
                                            <TextField
                                                label="Negative Marks"
                                                type="number"
                                                size="small"
                                                value={item.negativeMarks}
                                                onChange={(e) => handleInputChange("negativeMarks", e.target.value, index)}
                                            />
                                            {/* {err.negativeMarks && <span className="text-danger">{err.negativeMarks}</span>} */}
                                        </div>
                                    </div>

                                    <div className="d-flex justify-content-around align-items-center mt-3">


                                        <Button
                                            variant="contained"
                                            color="error"
                                            className="mt-3"
                                            onClick={() => handleRemove(index)}
                                        >
                                            Remove Question
                                        </Button>

                                    </div>

                                </form>
                            </div>

                        ))}
                        <div className="d-flex justify-content-around align-items-center mt-3 py-5">
                            <Link to="/questions">
                                <Button
                                    variant="contained"
                                    color="light"
                                // onClick={handleCancel}
                                >
                                    Cancel
                                </Button>
                            </Link>

                            <Button
                                variant="contained"
                                color="success"
                                onClick={handleSaveBulk}
                                disabled={loading}
                                className='px-5'
                            >
                                {loading ? 'Saving...' : 'Save'}
                            </Button>
                        </div>
                    </div>
                    : (<p className='text-center fw-bold'>No data </p>)
                }
            </div>

        </div>
    )
}

export default QuestionBulkUpload




// import React, { useEffect, useState } from "react";
// import Typography from "@mui/material/Typography";
// import {
//     Button,
//     FormControl,
//     InputLabel,
//     MenuItem,
//     Select,
//     Radio,
//     RadioGroup,
//     FormControlLabel,
//     TextField,
//     Checkbox,
// } from "@mui/material";
// import DeleteIcon from "@mui/icons-material/Delete";
// import ReactQuill from "react-quill";
// import "react-quill/dist/quill.snow.css"; // Import Quill CSS
// import Service from "../../service/Service";
// import { Link } from "react-router-dom";
// import QuestionImport from "./QuestionImport";

// function QuestionBulkUpload() {
//     const [bulkData, setBulkData] = useState([]);
//     const [loading, setLoading] = useState(false);
//     const [sectionsList, setSectionList] = useState([]);

//     // Fetch section list from the API
//     const fetchSections = async () => {
//         try {
//             const res = await Service.get("/getAllSections");
//             setSectionList(res.data.result);
//         } catch (error) {
//             console.error("Error fetching sections:", error);
//         }
//     };

//     useEffect(() => {
//         fetchSections();
//     }, []);

//     // Handle input change for a specific question field
//     const handleInputChange = (field, value, questionIndex) => {
//         const updatedBulkData = [...bulkData];
//         updatedBulkData[questionIndex][field] = value;
//         setBulkData(updatedBulkData);
//     };

//     // Handle adding a new option
//     const addOption = (questionIndex) => {
//         const updatedBulkData = [...bulkData];
//         updatedBulkData[questionIndex].options.push({
//             label: "",
//             isSelected: false,
//         });
//         setBulkData(updatedBulkData);
//     };

//     // Handle deleting an option
//     const deleteOption = (questionIndex, optionIndex) => {
//         const updatedBulkData = [...bulkData];
//         updatedBulkData[questionIndex].options.splice(optionIndex, 1);
//         setBulkData(updatedBulkData);
//     };

//     // Handle changing option text
//     const handleOptionChange = (questionIndex, optionIndex, value) => {
//         const updatedBulkData = [...bulkData];
//         updatedBulkData[questionIndex].options[optionIndex].label = value;
//         setBulkData(updatedBulkData);
//     };

//     const handleSelectionChange = (questionIndex, optionIndex) => {
//         setBulkData((prevBulkData) => {
//             // Clone the existing questions and the target question for immutability
//             const updatedQuestions = [...prevBulkData];
//             const question = { ...updatedQuestions[questionIndex] };

//             // Update the options based on question type
//             if (question.questionType === "multipleCorrect") {
//                 question.options = question.options.map((option, idx) => ({
//                     ...option,
//                     isSelected: idx === optionIndex ? !option.isSelected : option.isSelected,
//                 }));
//                 // Update correctAnswers based on selected options
//                 question.correctAnswers = question.options
//                     .map((option, idx) => (option.isSelected ? idx : null))
//                     .filter((idx) => idx !== null);
//             } else if (question.questionType === "singleCorrect") {
//                 question.options = question.options.map((option, idx) => ({
//                     ...option,
//                     isSelected: idx === optionIndex,
//                 }));
//                 // Update correctAnswers with the single selected option index
//                 question.correctAnswers = [optionIndex];
//             }

//             // Replace the updated question back into the array
//             updatedQuestions[questionIndex] = question;

//             return updatedQuestions;
//         });
//     };


//     // Process the bulk data before saving
//     const processBulkData = (data) => {
//         return data.map((item) => ({
//             ...item,
//             correctAnswers: item.options
//                 .filter((option) => option.isSelected)
//                 .map((option) => option.label),
//         }));
//     };

//     // Save bulk questions to the server
//     const handleSaveBulk = async () => {
//         const payload = processBulkData(bulkData);
//         setLoading(true);
//         try {
//             await Service.post("/createQuestion", payload);
//             alert("Questions saved successfully!");
//             setBulkData([]);
//         } catch (error) {
//             console.error("Error saving questions:", error);
//             alert("Failed to save questions.");
//         } finally {
//             setLoading(false);
//         }
//     };

//     // Remove a question
//     const handleRemoveQuestion = (index) => {
//         const updatedBulkData = bulkData.filter((_, idx) => idx !== index);
//         setBulkData(updatedBulkData);
//     };

//     // Handle bulk data upload
//     const handleBulkUpload = (data) => {
//         setBulkData(data.pages_data);
//     };

//     return (
//         <div className="Create_container">
//             <Typography variant="h4" component="h2" gutterBottom>
//                 Question Bulk Import
//             </Typography>

//             {/* Import functionality */}
//             <QuestionImport onBulkUpload={handleBulkUpload} />

//             {/* Question editing */}
//             {bulkData.length > 0 && (
//                 <div>
//                     {bulkData.map((item, questionIndex) => (
//                         <div key={questionIndex} className="bg-light rounded my-4 p-3">
//                             <form>
//                                 {/* Question Type */}
//                                 <FormControl fullWidth margin="normal">
//                                     <InputLabel>Question Type</InputLabel>
//                                     <Select
//                                         label="Question Type"
//                                         value={item.questionType}
//                                         onChange={(e) =>
//                                             handleInputChange("questionType", e.target.value, questionIndex)
//                                         }
//                                     >
//                                         <MenuItem value="singleCorrect">Single Correct</MenuItem>
//                                         <MenuItem value="multipleCorrect">Multiple Correct</MenuItem>
//                                         <MenuItem value="yesno">Yes / No</MenuItem>
//                                     </Select>
//                                 </FormControl>

//                                 {/* Section */}
//                                 <FormControl fullWidth margin="normal">
//                                     <InputLabel>Section</InputLabel>
//                                     <Select
//                                         label="Section"
//                                         value={item.section}
//                                         onChange={(e) =>
//                                             handleInputChange("section", e.target.value, questionIndex)
//                                         }
//                                     >
//                                         {sectionsList.map((section, idx) => (
//                                             <MenuItem key={idx} value={section.Section}>
//                                                 {section.Section}
//                                             </MenuItem>
//                                         ))}
//                                     </Select>
//                                 </FormControl>

//                                 {/* Question Name */}
//                                 <ReactQuill
//                                     theme="snow"
//                                     value={item.questionName}
//                                     onChange={(content) =>
//                                         handleInputChange("questionName", content, questionIndex)
//                                     }
//                                     placeholder="Write your question here..."
//                                 />

//                                 {/* Options */}
//                                 <div className="mt-3">
//                                     {item.options.map((option, optionIndex) => (
//                                         <div key={optionIndex} className="d-flex align-items-center">
//                                             {item.questionType === "multipleCorrect" ? (
//                                                 <Checkbox
//                                                     checked={option.isSelected}
//                                                     onChange={() =>
//                                                         handleSelectionChange(questionIndex, optionIndex)
//                                                     }
//                                                 />
//                                             ) : (
//                                                 <Radio
//                                                     checked={option.isSelected}
//                                                     onChange={() =>
//                                                         handleSelectionChange(questionIndex, optionIndex)
//                                                     }
//                                                 />
//                                             )}
//                                             <TextField
//                                                 value={option}
//                                                 onChange={(e) =>
//                                                     handleOptionChange(
//                                                         questionIndex,
//                                                         optionIndex,
//                                                         e.target.value
//                                                     )
//                                                 }
//                                                 placeholder={`Option ${optionIndex + 1}`}
//                                                 variant="outlined"
//                                                 size="small"
//                                                 className="me-2"
//                                             />
//                                             <Button
//                                                 onClick={() => deleteOption(questionIndex, optionIndex)}
//                                                 variant="contained"
//                                                 color="error"
//                                                 size="small"
//                                             >
//                                                 <DeleteIcon />
//                                             </Button>
//                                         </div>
//                                     ))}
//                                     <Button
//                                         variant="contained"
//                                         onClick={() => addOption(questionIndex)}
//                                         className="mt-2"
//                                     >
//                                         Add Option
//                                     </Button>
//                                 </div>

//                                 {/* Score and Negative Marks */}
//                                 <div className="d-flex mt-3">
//                                     <TextField
//                                         label="Score"
//                                         type="number"
//                                         size="small"
//                                         value={item.score || ""}
//                                         onChange={(e) =>
//                                             handleInputChange("score", e.target.value, questionIndex)
//                                         }
//                                         className="me-3"
//                                     />
//                                     <TextField
//                                         label="Negative Marks"
//                                         type="number"
//                                         size="small"
//                                         value={item.negativeMarks || ""}
//                                         onChange={(e) =>
//                                             handleInputChange(
//                                                 "negativeMarks",
//                                                 e.target.value,
//                                                 questionIndex
//                                             )
//                                         }
//                                     />
//                                 </div>

//                                 {/* Remove Question */}
//                                 <Button
//                                     variant="contained"
//                                     color="error"
//                                     className="mt-3"
//                                     onClick={() => handleRemoveQuestion(questionIndex)}
//                                 >
//                                     Remove Question
//                                 </Button>
//                             </form>
//                         </div>
//                     ))}

//                     {/* Save and Cancel Buttons */}
//                     <div className="d-flex justify-content-between mt-4">
//                         <Link to="/questions">
//                             <Button variant="contained">Cancel</Button>
//                         </Link>
//                         <Button
//                             variant="contained"
//                             color="success"
//                             onClick={handleSaveBulk}
//                             disabled={loading}
//                         >
//                             {loading ? "Saving..." : "Save"}
//                         </Button>
//                     </div>
//                 </div>
//             )}
//         </div>
//     );
// }

// export default QuestionBulkUpload;
