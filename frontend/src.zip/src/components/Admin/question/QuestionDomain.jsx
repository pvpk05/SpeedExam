import React, { useEffect, useState } from 'react';
import Service from '../../service/Service';
import { Link } from 'react-router-dom';


function QuestionDomain() {

    const [domainList, setDomainList] = useState([]);


    const fetchDomains = async () => {
        try {
            const res = await Service.get('/getAllDomains');
            console.log(res);
            
            setDomainList(res.data.result || []);
        } catch (error) {
            console.error('Error fetching domains:', error);
        }
    };

    // Fetch domains on mount
    useEffect(() => {
        fetchDomains();
    }, []);

    console.log('AAA'+domainList);
    


    return (
        <div className='container p-5 bg'>
            <div className="row">
                {domainList.length === 0 && (
                    <span className='text-center fw-bold'>No domains added as of now</span>
                )}
                {domainList.map((item, index) => (
                    <div className="col-3 p-3" key={index}>
                        <Link to={`/questions/add/${item.Domain}`} className='text-decoration-none'>
                            <div className="card p-5 bg-secondary ">

                                <span className='fw-bold text-center'>{item.Domain}</span>

                            </div>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default QuestionDomain;
