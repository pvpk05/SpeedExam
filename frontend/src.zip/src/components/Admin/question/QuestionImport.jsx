/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */


import React, { useRef } from 'react';
import * as XLSX from 'xlsx';
import { Button} from "@mui/material";

function QuestionImport({ onBulkUpload }) {

    const fileInputRef = useRef(null);

    const handleButtonClick = () =>
        fileInputRef.current.click();



    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = (event) => {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                const formattedData = formatData(json);
                onBulkUpload(formattedData);
            } catch (error) {
                console.error('Error parsing file:', error);
            }
        };

        reader.onerror = (error) => {
            console.error('Error reading file:', error);
        };

        reader.readAsArrayBuffer(file);
    };

    const formatData = (json) => {
        const headers = json[0];
        const data = json.slice(1);

        const pages_data = [];

        data.forEach((row) => {
            const question = {
                QID: row[headers.indexOf('S No.')],
                section: row[headers.indexOf('SUBJECT')],
                questionName: row[headers.indexOf('QUESTION TEXT')],
                options: [
                    row[headers.indexOf('OPTION1')],
                    row[headers.indexOf('OPTION2')],
                    row[headers.indexOf('OPTION3')],
                    row[headers.indexOf('OPTION4')],
                    row[headers.indexOf('OPTION5')],
                    row[headers.indexOf('OPTION6')],
                    row[headers.indexOf('OPTION7')],
                    row[headers.indexOf('OPTION8')],
                    row[headers.indexOf('OPTION9')],
                    row[headers.indexOf('OPTION10')]
                ].filter(option => option !== null && option !== undefined && (typeof option === 'string' ? option.trim() !== '' : true)),
                description: row[headers.indexOf('EXPLANATION')],
                questionType: row[headers.indexOf('QUESTION TYPE')],
                correctAnswer: [row[headers.indexOf('RIGHT ANSWER')]],
                score: row[headers.indexOf('CORRECT MARKS')],
                negativeMarks: row[headers.indexOf('NEGATIVE MARKS')],
            };
            console.log(question);
            pages_data.push(question);
        });
        console.log(pages_data);
        return {
            pages_data
        };
    };




    return (
        <div>
            <Button variant="contained" color="success" onClick={handleButtonClick} >
                Import
            </Button>
            <input
                type="file"
                accept=".xlsx"
                onChange={handleFileUpload}
                ref={fileInputRef}
                style={{ display: 'none' }}
            />
        </div>
    )
}

export default QuestionImport